function Sol = BoundSearchSpace( Sol1 )
                
    global ProblemSettings

    VarMin=ProblemSettings.VarMin;
    VarMax=ProblemSettings.VarMax; 
    
    % Brigs Out of Search Space Individuals to the Search Space
    Sol1(1) = max(Sol1(1),0);
    Sol1(1) = min(Sol1(1),1);    

    Sol1(2:end) = max(Sol1(2:end),VarMin(2:end);
    Sol1(2:end) = min(Sol1(2:end),VarMax(2:end); 
    
    Sol=Sol1;

end

