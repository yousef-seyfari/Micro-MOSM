
function Rep=CircularCrowding(Rep)    
    
    % Sort Repository
    tmp=[Rep.Cost];
    [~,ind]=sort(tmp(1,:));
    Rep=Rep(ind);
    R=0.05;
    costs=[Rep.Cost]';
    [~,I,~] = unique(costs, 'rows', 'first'); 
    Rep=Rep(I);
    for i=1:numel(Rep)
        Rep(i).CD=0;
        Rep(i).NShare=0;
    end
    
    if numel(Rep)>=2
        costs=[Rep.Cost]';
        commonDis = zeros(1,numel(Rep));
        for i=1:size(costs,2)
            [~,rank] = sortrows(costs(:,i));
            commonDis(rank(1))   = -inf;
            commonDis(rank(end)) = -inf;
            for j = 1 : size(costs,1)-1
                curr=costs(rank(j),i);
                common=0;
                if (costs(rank(j+1),i)-R)<(curr+R)
                   common=(curr+R)-(costs(rank(j+1),i)-R);
                end
                if (j~=1 && j~=(numel(Rep)-1))
                    Rep(rank(j)).CD=Rep(rank(j)).CD+common;
                    Rep(rank(j+1)).CD=Rep(rank(j+1)).CD+common;
                elseif j==1
                    Rep(rank(j+1)).CD=Rep(rank(j+1)).CD+common;
                elseif j==(numel(Rep)-1)
                    Rep(rank(j)).CD=Rep(rank(j)).CD+common;
                end
            end

        end
        for j = 1 : size(costs,2)
            [~,rank] = sortrows(costs(:,i));
            Rep(rank(1)).CD   = -inf;
            Rep(rank(end)).CD   = -inf; 
            Rep(rank(1)).NShare   = 0;
            Rep(rank(end)).NShare   = 0; 
        end
    elseif numel(Rep)==1
        Rep(1).CD=-inf;
        Rep(1).NShare=0;
    end
 
end