plot(HV(:,1),'o-','MarkerIndices',1:5:length(HV(:,1)))
plot(HV(:,1),'o-','MarkerIndices',1:20:length(HV(:,1)))
plot(HV(:,1),'o-','MarkerIndices',1:50:length(HV(:,1)))
plot(HV(:,1),'o-','MarkerIndices',1:100:length(HV(:,1)))
plot(HV(:,1),'o-','MarkerIndices',1:200:length(HV(:,1)))
plot(HV(:,1),'o-','MarkerIndices',1:150:length(HV(:,1)))

plot(SCR(:,1),'*-','MarkerIndices',1:500:length(HV(:,1)))
plot(SCR(:,1),'*-','MarkerIndices',1:1000:length(HV(:,1)))
plot(SCR(:,1),'*-','MarkerIndices',1:2000:length(HV(:,1)))
plot(SCR(:,1),'*-','MarkerIndices',1:4000:length(HV(:,1)))

p5=semilogy(DiversityPlot(:,5),'-.','color','red','LineWidth',2);
p6=semilogy(BestCostPlot(:,6),'--','color','blue','LineWidth',1.5);

p1=plot(moga(:,1),'o-','MarkerIndices',1:100:length(moga),'color','blue','LineWidth',1.5);
hold on;
p2=plot(mopso(:,1),'*-','MarkerIndices',1:100:length(mopso),'color','green','LineWidth',1.5);
hold on;
p4=plot(mosm2(:,1),'+-','MarkerIndices',1:100:length(mosm2),'color','red','LineWidth',1.5);
hold on;
p3=plot(mosm1(:,1),'<-','MarkerIndices',1:100:length(mosm1),'color','cyan','LineWidth',1.5);
hold off;
h = [p1;p2;p3;p4];
lege=legend(h,'Location', [0.5 0.5 0.15 0.05],'    MOGA','    MOPSO','    MOSM-C1','    MOSM-C2');
x=xlabel('Generations');
y=ylabel('Hypervolume');
lege.FontSize=8;
lege.FontName='times';
x.FontName='times';
y.FontName='times';



p4=plot(cr(:,4),'^-','MarkerIndices',1:40:length(cr),'color','black');
hold on;
p5=plot(cr(:,4),'<-','MarkerIndices',1:40:length(cr),'color','cyan');



















p1=plot(hv1(:,1),'o-','MarkerIndices',1:100:length(hv1),'color','green','LineWidth',1.5);
hold on;
p2=plot(hv2(:,1),'*-','MarkerIndices',1:100:length(hv2),'color','blue','LineWidth',1.5);
hold on;
p3=plot(hv3(:,1),'+-','MarkerIndices',1:100:length(hv3),'color','red','LineWidth',1.5);
hold on;
p4=plot(hv4(:,1),'^-','MarkerIndices',1:100:length(hv4),'color','black','LineWidth',1.5);
hold on;
p5=plot(hv5(:,1),'<-','MarkerIndices',1:100:length(hv5),'color','magenta','LineWidth',1.5);
hold on;
p6=plot(hv6(:,1),'>-','MarkerIndices',1:100:length(hv6),'color','yellow','LineWidth',1.5);
hold on;

hold off;
h = [p1;p2;p3;p4;p5;p6];
lege=legend(h,'Location', [0.5 0.5 0.15 0.05],'Scenario 1','Scenario 2','Scenario 3','Scenario 4','Scenario 5','Scenario 6');
x=xlabel('Generations');
y=ylabel('Hypervolume');
lege.FontSize=8;
lege.FontName='times';
x.FontName='times';
y.FontName='times';
