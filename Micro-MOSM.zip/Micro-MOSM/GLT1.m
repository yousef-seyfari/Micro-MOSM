function popobj = GLT1(X)
    %compute g  OK mi
    result=0;
    count=numel(X);
    for i=2:count
       value = X(i)-sin(2*pi*X(1)+(i)*pi/count);
       result = result + value*value;
    end
    g=result;
    
    %evaluate
    obj0 = (1.0 + g)*X(1);
    obj1 = (1.0 + g)*(2.0-X(1)-sign(cos(2*pi*X(1))));
    popobj = [obj0, obj1]';
    %popobj=round(popobj, 4);
end