function Structure=Movement(Structure, Rep, Rep2, it)
    
    
    global ProblemSettings
    global SM_Settings
    
    
    CostFunction=ProblemSettings.CostFunction;
    VarSize=ProblemSettings.VarSize;
    VarMin=ProblemSettings.VarMin;
    MaxIt=ProblemSettings.MaxIt;
    nVar=ProblemSettings.nVar;
    VarMax=ProblemSettings.VarMax;  
    nSol=numel(Structure); 
    L=SM_Settings.L;
    intensity=1;
    
    for i=1:nSol
        
        % Get the Group Style Vector
        Style=Structure(i).Style;

        % Compute Probability Vector for i'th Style Vector of Solution
         P=exp(-Style/sum(Style));
         P=1-P;
         P=P/sum(P);
         % Select one of the Groups based on the Probability Vector
         % and Roulette Wheel Selection Method
         
         Selected_Style1=RouletteWheelSelection(P,1);%
         Selected_Style = SM_Settings.Style_pool(Selected_Style1);
        
         switch Selected_Style    % Which optimization methods should be run
                                 % at first they shoul be oprdered from 1                                                                 
                                    
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 1 % Simulated binary crossover                                
                Parent1=Structure(i);
                %Parent2=Rep(randi(numel(Rep)));%Rep(Selected_Sol(1));
                Parent2=getaSolFromRep(Rep, Rep2);%***

                beta = zeros(1,nVar);
                mu   = rand(1,nVar);
                [proC,disC,proM,disM] = deal(1,20,1,10);
                beta(mu<=0.5) = (2*mu(mu<=0.5)).^(1/(disC+1));
                beta(mu>0.5)  = (2-2*mu(mu>0.5)).^(-1/(disC+1));
                beta = beta.*(-1).^randi([0,1],1,nVar);
                beta(rand(1,nVar)<0.5) = 1;
                beta(repmat(rand(1,1)>proC,1,nVar)) = 1;
                %me ***
                %beta = 1.2 * beta;
                Offspring = [(Parent1.Decision+Parent2.Decision)/2+beta.*(Parent2.Decision-Parent1.Decision)/2
                             (Parent2.Decision+Parent1.Decision)/2-beta.*(Parent2.Decision-Parent1.Decision)/2];
                      
                % Polynomial mutation
                Site  = rand(1,nVar) < proM/nVar;
                mu    = rand(1,nVar);
                temp  = Site & mu<=0.5;
                Vmin=VarMin;Vmax=VarMax;
                Vmin(1,:)=VarMin;Vmax(1,:)=VarMax;
                Offspring(temp) = Offspring(temp)+intensity.*((Vmax(temp)-Vmin(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                                  (1-(Offspring(temp)-Vmin(temp))./(Vmax(temp)-Vmin(temp))).^(disM+1)).^(1/(disM+1))-1));
                temp = Site & mu>0.5; 
                Offspring(temp) = Offspring(temp)+intensity.*((Vmax(temp)-Vmin(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                                  (1-(Vmax(temp)-Offspring(temp))./(Vmax(temp)-Vmin(temp))).^(disM+1)).^(1/(disM+1))));

                Offspring = min(max(Offspring,VarMin),VarMax); 
                if rand<=0.5
                    sel=1;
                else
                    sel=2;
                end
                Structure(i).Decision=Offspring(sel,:);
                Structure(i).Cost=CostFunction(Offspring(sel,:));
              
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 2      %DE from ADE-MOAIS          
%                 costs=[Rep.Cost];
%                 cds=[Rep.CD];
%                 if all(cds==inf)
%                     cds = ones(size(cds));
%                 else
%                     cds(cds==inf) = 2*max(cds(cds~=inf));
%                 end
%                 s_costs=sum(costs,1);
%                 s_cds=sum(cds,1);
%                 P3=exp(-s_cds/sum(s_cds));
%                 P1=exp(-s_costs/sum(s_costs));
%                 P1=1-P1;
%                 P=0.5*P3+0.5*P1;
%                 P=P/sum(P);
                
                Selected_Sol=randi(numel(Rep));%RouletteWheelSelection(P,1);% 
                %sol = getaSolFromRep(Structure(i), Rep, Rep2);%*** %for
                %fuzzy
                sol = getaSolFromRep(Rep, Rep2);

                %me ***
                %F= cauchy_dist(0.9, 0.1); %original
                F= cauchy_dist(0.9, 0.1);
                %original
                %v=Rep(randi(numel(Rep))).Decision+F*(...
                %        Rep(Selected_Sol).Decision-Structure(randi(nSol)).Decision);  
                v=Rep(randi(numel(Rep))).Decision+F*(...
                        sol.Decision-Structure(randi(nSol)).Decision);  

                y=zeros(1,nVar);
                j0=randi([1 nVar]);
                %me ***
                %CR=0.1+1/pi*(atan((1-it/MaxIt-0.8)/0.1));
                %original
                CR=0.35+1/pi*(atan((1-it/MaxIt-0.8)/0.1));
                for k=1:nVar
                    if k==j0 || rand<=CR
                        y(k)=v(k);
                    else
                        y(k)=Structure(i).Decision(k);
                    end
                end
                y=min(max(y,VarMin),VarMax);
                Structure(i).Decision= y;
                Structure(i).Cost=CostFunction(Structure(i).Decision);
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             case 3 % Uniform mutation
                 x=unifrnd(VarMin,VarMax,VarSize);
                 %me ***
                 %original
                 nf=ceil(nVar*0.05);
                 %nf=ceil(nVar*0.1);
                 idx=randsample(nVar, nf);
                 Structure(i).Decision(idx)=intensity*x(idx);
                 Structure(i).Cost=CostFunction(Structure(i).Decision);
                 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 4 %WOA
                costs=[Rep.Cost];
                cds=[Rep.CD];
                
                Selected_Sol=randi(numel(Rep));% 
                sol = getaSolFromRep(Rep, Rep2);
                
                a=4-it*((4)/MaxIt); 
                A=2*a*rand-a;  % Eq. (2.3) in the paper
                C=2*rand;      % Eq. (2.4) in the paper
                if rand<0.5   
                    %D_Leader=abs(C*Rep(Selected_Sol).Decision-Structure(i).Decision); % Eq. (2.1)
                    D_Leader=abs(C*sol.Decision-Structure(i).Decision); % Eq. (2.1)
                    %Structure(i).Decision=Rep(Selected_Sol).Decision-A*D_Leader;      % Eq. (2.2)
                    Structure(i).Decision=sol.Decision-A*D_Leader;      % Eq. (2.2)

                else
                    a2=-2+it*((-2)/MaxIt);
                    b=1;               %  parameters in Eq. (2.5)
                    l=(a2-1)*rand+1;   %  parameters in Eq. (2.5)
                    %distance2Leader=abs(Rep(Selected_Sol).Decision-Structure(i).Decision);
                    distance2Leader=abs(sol.Decision-Structure(i).Decision);
                    %Structure(i).Decision=distance2Leader*exp(b.*l).*cos(l.*2*pi)+Rep(Selected_Sol).Decision;
                    Structure(i).Decision=distance2Leader*exp(b.*l).*cos(l.*2*pi)+sol.Decision;

                end
                Structure(i).Decision= min(max(Structure(i).Decision,VarMin),VarMax);
                Structure(i).Cost=CostFunction(Structure(i).Decision);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
            case 5  %FA
                costs=[Rep.Cost];

                Selected_Sol=randi(numel(Rep));%   
                sol = getaSolFromRep(Rep, Rep2);
                               
                D=0;
                pos=[];
                for jj=1:numel(Rep)
                    D=D+abs(Structure(i).Decision-Rep(jj).Decision);
                    pos(jj,:)=Rep(jj).Decision;                
                end
                avg=mean(pos,1); vrs=var(pos,1);
                sigma=D/(numel(Rep));
                %Structure(i).Decision=Structure(i).Decision+1.5*rand.*(...
                    %Structure(i).Decision-Rep(Selected_Sol).Decision);
                dmax = norm(VarMax-VarMin);
                %rij = norm(Rep(Selected_Sol).Decision-Structure(i).Decision)/dmax;
                rij = norm(sol.Decision-Structure(i).Decision)/dmax;
                beta = 2*exp(-2*rij.^1);
                e = 0.1*(VarMax-VarMin).*unifrnd(-1, +1, VarSize);
                
                %Structure(i).Decision = Structure(i).Decision ...
                %+ rand.*rand(VarSize).*(Rep(Selected_Sol).Decision-Structure(i).Decision) ...
                %+ SM_Settings.alpha.*e;
            
            Structure(i).Decision = Structure(i).Decision ...
                + rand.*rand(VarSize).*(sol.Decision-Structure(i).Decision) ...
                + SM_Settings.alpha.*e;
                %SM_Settings.alpha =SM_Settings.alpha*0.9999;%1-(it/MaxIt)^3;%
                Structure(i).Decision = min(max(Structure(i).Decision,VarMin),VarMax); 
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=CostFunction(Structure(i).Decision);
                
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 6  %Gaussian Mutation
                Offspring=Structure(i).Decision;
                %Offspring=Rep(randi(numel(Rep))).Decision;  %original
                %sol = getaSolFromRep(Structure(i), Rep, Rep2);%for fuzzy
                sol = getaSolFromRep(Rep, Rep2);
                Offspring=sol.Decision;
                Offspring = min(max(Offspring,VarMin),VarMax);  
                Structure(i).Decision=intensity.*Offspring;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=CostFunction(Offspring);
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            case 7 %Polynomial Mutation
                  Offspring=Structure(i).Decision;              
                  [proM,disM] = deal(1,12);
                  Site  = rand(1,nVar) < proM/nVar;
                  mu    = rand(1,nVar);
                  temp  = Site & mu<=0.5;
                  Offspring=Structure(i).Decision;
                  Offspring(temp) = Offspring(temp)+(VarMax(temp)-VarMin(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                                      (1-(Offspring(temp)-VarMin(temp))./(VarMax(temp)-VarMin(temp))).^(disM+1)).^(1/(disM+1))-1);
                  temp = Site & mu>0.5; 
                  Offspring(temp) = Offspring(temp)+(VarMax(temp)-VarMin(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                                      (1-(VarMax(temp)-Offspring(temp))./(VarMax(temp)-VarMin(temp))).^(disM+1)).^(1/(disM+1)));

                  Offspring = min(max(Offspring,VarMin),VarMax);  
                  Structure(i).Decision=intensity.*Offspring;
                  Structure(i).PrevCost=Structure(i).Cost;
                  Structure(i).Cost=CostFunction(Offspring);

         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                   
            case 8 %Sin Cosin                
                a = 2;                                    
                costs=[Rep.Cost];
                 Selected_Sol=randi(numel(Rep));% 
                 sol=getaSolFromRep(Rep, Rep2);

                %mm=(Rep(Selected_Sol).Decision-Structure(i).Decision);
                %original
                mm=(sol.Decision-Structure(i).Decision);

                r1=a-it*((a)/MaxIt); 

                r2=(2*pi)*randn();
                r3=2*randn;
                r4=randn();

                if r4<=0.5
                    newSol= Structure(i).Decision+r1*(sin(r2)*abs(r3*mm - ...
                        Structure(i).Decision));
                else                   
                    newSol= Structure(i).Decision+r1*(cos(r2)*(r3*mm - ...
                        Structure(i).Decision));
                end
             
                newSol = max(newSol, VarMin);
                newSol = min(newSol, VarMax);

                Structure(i).Decision=newSol;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=CostFunction(newSol);                       
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
                
            case 9  % Extended line crossover  or BLX-0.25                
                costs=[Rep.Cost];
                Selected_Sol=randi(numel(Rep));% 
                sol=getaSolFromRep(Rep, Rep2);
                 
                Parent1=Structure(i);
                %Parent2=Rep(Selected_Sol);
                Parent2=sol;
                
                I=(Parent2.Decision-Parent1.Decision);
                r=unifrnd(-1.5,1.5, VarSize);

                Offspring=Parent1.Decision+r.*(Parent2.Decision-Parent1.Decision);
                         
                Offspring = min(max(Offspring,VarMin),VarMax);   
                
                Structure(i).Decision=Offspring;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=CostFunction(Offspring);               
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            case 10 % Modified GWO 
                cds=[Rep.CD];
                id=find(cds==-inf);
                ssx=randi(numel(id));
                if numel(id)==2
                    Selected_Sol(1)=id(1);
                    Selected_Sol(2)=id(2);
                    Selected_Sol(3)=randi(numel(Rep));
                    %Selected_Sol(3)=getaSolFromRep(Rep, Rep2);
                elseif numel(id)==1
                    Selected_Sol(1)=id(1);
                    Selected_Sol(2)=randi(numel(Rep));
                    %Selected_Sol(2)=getaSolFromRep(Rep, Rep2);
                    Selected_Sol(3)=randi(numel(Rep));
                    %Selected_Sol(3)=getaSolFromRep(Rep, Rep2);
                else
                    Selected_Sol(1)=id(1);
                    Selected_Sol(2)=id(2);
                    Selected_Sol(3)=randi(numel(Rep));
                    %Selected_Sol(3)=getaSolFromRep(Rep, Rep2);
                end
                    
%                 for qq=1:3
%                     se=randi(3);
%                     if se == 1
%                         Selected_Sol(1)=1;
%                         Selected_Sol(2)=numel(Rep);
%                         Selected_Sol(3)=randi(numel(Rep));
%                     elseif se == 2
%                         Selected_Sol(1)=1;
%                         Selected_Sol(2)=randi(numel(Rep));
%                         Selected_Sol(3)=numel(Rep);
%                     else
%                         Selected_Sol(1)=randi(numel(Rep));
%                         Selected_Sol(2)=1;
%                         Selected_Sol(3)=numel(Rep);
%                     end
%                 end
                alpha=Rep(Selected_Sol(1));
                beta=Rep(Selected_Sol(2));
                delta=Rep(Selected_Sol(3));
                
                temp=zeros(1,nVar);
                a=2-it*((2)/MaxIt); 
                for kk=1:size(Structure(i).Decision,2)     

                    r1=unifrnd(-1,1); % 
                    r2=rand(); % 

                    A1=2*a*r1-a; % 
                    C1=2*r2; %
                    
                    D_alpha=abs(alpha.Decision(kk)-Structure(i).Decision(kk)); 
                    X1=(alpha.Decision(kk)-r1*D_alpha); 

                    r1=unifrnd(-1,1);
                    r2=rand();

                    A2=2*a*r1-a; 
                    C2=2*r2; % 

                    D_beta=abs(beta.Decision(kk)-Structure(i).Decision(kk)); 
                    X2=(beta.Decision(kk)-r1*D_beta);      

                    r1=unifrnd(-1,1);
                    r2=rand(); 

                    A3=2*a*r1-a; 
                    C3=2*r2; 

                    D_delta=abs(delta.Decision(kk)-Structure(i).Decision(kk)); 
                    X3=(delta.Decision(kk)-r1*D_delta);        
                    
                    temp(kk)=(X1+X2+X3)/3;             
                                        
                end
                Offspring=temp;
                Offspring = min(max(Offspring,VarMin),VarMax);   
                
                newC=CostFunction(Offspring);
                
                Structure(i).Decision=Offspring;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=CostFunction(Offspring);                     
               %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
               
            case 11  %TLBO Teaching
                costs=[Rep.Cost];
                cds=[Rep.CD];               
                Selected_Sol=randi(numel(Rep));   
                sol = getaSolFromRep(Rep, Rep2);
                
                Mean=0;
                for k = 1:numel(Structure)
                    Mean = Mean + Structure(k).Decision;
                end
                Mean = Mean/nSol;    
                TF = randi([1 2]);
                % Teaching 
                %newsol = Structure(i).Decision ...
                %    + rand(VarSize).*(Rep(Selected_Sol).Decision - TF*Mean);
                
                newsol = Structure(i).Decision ...
                    + rand(VarSize).*(sol.Decision - TF*Mean);
                
                % Clipping
                newsol = max(newsol, VarMin);
                newsol = min(newsol, VarMax);
                % Evaluation
                newCost = CostFunction(newsol);
                % Comparision
                %if Dominates(newCost,Structure(i).Cost)
                    Structure(i).Decision = newsol;
                    Structure(i).Cost=newCost;
                %end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 12  %TLBO Learning 
                A = 1:nSol;
                A(i) = [];
                q = A(randi(nSol-1));
                Step = Structure(i).Decision - Structure(q).Decision;
                if Dominates(Structure(q).Cost, Structure(i).Cost)
                    Step = -Step;
                end
                % Teaching (moving towards teacher)
                newsol = Structure(i).Decision + rand(VarSize).*Step;
                % Clipping
                newsol = max(newsol, VarMin);
                newsol = min(newsol, VarMax);
                % Evaluation
                newCost = CostFunction(newsol);
                % Comparision
                %if Dominates(newCost,Structure(i).Cost)
                    Structure(i).Decision = newsol;
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Cost=newCost;
                %end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 13  %Bat
                costs=[Rep.Cost];
                cds=[Rep.CD];
                if all(cds==inf)
                    cds = ones(size(cds));
                else
                    cds(cds==inf) = 2*max(cds(cds~=inf));
                end

                Selected_Sol=randi(numel(Rep));%RouletteWheelSelection(P,1);% 
                sol=getaSolFromRep(Rep, Rep2);%RouletteWheelSelection(P,1);% 
                
                Qmin=0;
                Qmax=1;
                BATr=0.8;
                y=[];
                y.Decision=[];
                y.Cost=[];
                
                %me ***
                %sigma=0.05*(VarMax-VarMin);  original
                sigma=0.1*(VarMax-VarMin);

                k1=randi(numel(Structure));
                k2=randi(numel(Structure(k1)));
                y.Decision=Structure(i).Decision;

                Q=Qmin+(Qmax-Qmin)*rand;
                mm=((sol.Decision)-Structure(i).Decision);

                Structure(i).Velocity=rand*Structure(i).Velocity+Q*mm;

                y.Decision=Structure(i).Decision+Structure(i).Velocity;

                  % Pulse rate  r decresing
                if rand<L
                    %me ***
                   mu=0.1;  %original
                   %mu=0.15;
                   nMu=ceil(mu*nVar);
                   kk=randsample(nVar,nMu);
                   y.Decision(kk)=Structure(i).Decision(kk)+...
                       sigma(kk).*randn(size(kk'));
                end
                y.Decision=min(max(y.Decision,VarMin),VarMax);  
                y.Cost=CostFunction(y.Decision);

                Structure(i).Decision=y.Decision;
                Structure(i).Cost=y.Cost;
 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
                
        end  %END OF SWITCH
        Structure(i)=Update_Style(Structure(i), Selected_Style1);
    end   
    Structure=DetermineDomination(Structure, i);
    %Rep=MakeRepository(Structure, Rep);        

    
end  %End of function



