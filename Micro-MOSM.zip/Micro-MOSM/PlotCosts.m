
function PlotCosts(rep1, rep2, rep3)
    
    figure(1);
    %set(gca, 'FontName', 'Times');
    
    %rep_costs=[rep.Cost];
%     rep_costs1=rep1;
%     rep_costs2=rep2;
%     rep_costs3=rep3;
%     rep_costs4=rep4;
%     rep_costs5=rep5;
%     rep_costs6=rep6;
%     
%     p1=plot(rep_costs1(1,:),rep_costs1(2,:),'bo');
%     hold on;
%     p2=plot(rep_costs2(1,:),rep_costs2(2,:),'r*');
%     hold on;
%     p3=plot(rep_costs3(1,:),rep_costs3(2,:),'g+');
%     hold on;
%     p4=plot(rep_costs4(1,:),rep_costs4(2,:),'k^');
%     hold on;
%     p5=plot(rep_costs5(1,:),rep_costs5(2,:),'c<');
%      hold on;
%     p6=plot(rep_costs6(1,:),rep_costs6(2,:),'mp');
%      hold off;
%     h = [p1;p2;p3];
%     legend(h,'Location', [0.5 0.35 0.15 0.05],'MOSM/c5','Mb-MOSMc5','Mb-MOSM_abest/c5');
% %     for i=1:numel(Structure)
% %        pop_costs=[Structure(i).Group.Cost]; 
% %        plot(pop_costs(1,:),pop_costs(2,:),'r.');
% %     end
%     %title('Pareto fronts for D4');
%     xlabel('F_1');
%     ylabel('F_2');
%     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%PLOT  HV %%%%%%%%%%%%%%%%%%%%%%%%%    
    
p1=plot(PlotHV(:,1),'o-', 'color','blue');
hold on
p2=plot(PlotHV(:,2),'*-','color','red');
hold on
p3=plot(PlotHV(:,3),'+-','color','green');

hold off
h = [p1;p2;p3];
legend(h,'Location', [0.5 0.35 0.15 0.05],'MOSM/c5','Mb-MOSM/c5','Mb-MOSM_a_b_e_s_t/c5');
    
xlabel('Generations');
ylabel('Hypervolume');
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%PLOT CR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% cr=[];
% for j=1:5
% temp=[];
% temp=PlotCR(:,j);
% for i=0:80:8000
% if i>7920
% break;
% end
% ls=linspace(temp(i+1),temp(i+80),80);
% cr(i+1:i+80,j)=ls;
% end
% end
% 
% 
%     p1=plot(cr(:,1),'o-','MarkerIndices',1:80:length(cr),'color','blue');
%     hold on;
%     p2=plot(cr(:,2),'*-','MarkerIndices',1:80:length(cr),'color','red');
%     hold on;
%     p3=plot(cr(:,3),'+-','MarkerIndices',1:80:length(cr),'color','green');
%     hold on;
%     p4=plot(cr(:,4),'^-','MarkerIndices',1:80:length(cr),'color','black');
%     hold on;
%     p5=plot(cr(:,5),'<-','MarkerIndices',1:80:length(cr),'color','cyan');
%     hold off;
%     h = [p1;p2;p3;p4;p5];
%     legend(h,'Location', [0.5 0.5 0.15 0.05],'MOSM-Config1','MOSM-Config2','MOSM-Config3','MOSM-Config4','MOSM-Config5');
% 
% xlabel('Generations');
% ylabel('Consolidation Ratio');



end