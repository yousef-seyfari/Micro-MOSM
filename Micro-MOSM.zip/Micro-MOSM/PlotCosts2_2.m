
function PlotCosts2(rep,PF)
    
%     for i=1:nGroup
%         for j=1:numel(Structure(i).Group)
%            p_costs=[p_costs  Structure(i).Group(j).Cost];
%         end
%     end
    figure(1);
    grid on
    hold on
    rep_costs=rep;

    p1=plot(rep_costs(1,:),rep_costs(2,:),'bo');
    
    %hold on;

    p2=plot(PF(1,:),PF(2,:),'r-');
    
    h = [p1;p2];
    lege=legend(h,'Location', [0.5 0.35 0.15 0.05],'  MOSM-C1','True PF');
    hold on;
    lege.FontSize=8;
    lege.FontName='times';
        
    xl=xlabel('f_1');
    yl=ylabel('f_2');
    xl.FontName='times';
    yl.FontName='times';
    %ylabel('F_3');
    
    %hold off;
    

end