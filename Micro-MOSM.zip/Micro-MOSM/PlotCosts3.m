
function PlotCosts3(rep, PF)
    
    rep_costs=rep;

    p1=plot3(rep_costs(1,:),rep_costs(2,:), rep_costs(3,:),'bo');
    %hold on;
    grid on
    
    %p2=plot3(PF(1,:),PF(2,:), PF(3,:),'r-');
    
    %h = [p1;p2];    
%     hold on;
%     lege=legend(h,'Location', [0.5 0.35 0.15 0.05],'ADE-MOIA','True PF');
%     hold on;
%     lege.FontSize=8;
%     lege.FontName='times';
%         
%     xl=xlabel('f_1');
%     yl=ylabel('f_2');
%     zl=zlabel('f_3');
%     xl.FontName='times';
%     yl.FontName='times';
%     zl.FontName='times';
    

end