clc;
clear all;

%turn off last warning
%w = warning('query','last')
%id = w.identifier;
%warning('off',id)  %turn off
%warning('on',id)   %turn on


for Problem=[6]
    %%  Globalization of Parameters and Settings
   prob=num2str(Problem);
    %CostFunction=str2func(['@(x) LZ09' prob '(x)']);  %Cost Function
    %load(['Problem_PFs\LZ09' prob]);
    %problemName=['LZ09' prob ];
    CostFunction=str2func(['@(x) GLT' prob '(x)']);  %Cost Function
    load(['Problem_PFs\GLT' prob ]);
    problemName=['GLT' prob ];
    
    global ProblemSettings;
    global SM_Settings;
    global Rep2;
    global FLC
    
    VarMin=[]; VarMax=[];
    
    switch Problem
        case num2cell([1])
            SM_Settings.nObjective=2;
            SM_Settings.nRep=100;
            nPop=8;            
            nVar=30;
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;
		case num2cell([2 3 4 5])
            SM_Settings.nObjective=2;
            SM_Settings.nRep=100;
            nPop=8;
            nVar=30;
            VarMin(1)=0;
            VarMax(1)=1;
            VarMin(2:nVar)=-1;
            VarMax(2:nVar)=1;
        case num2cell([6])
            SM_Settings.nRep=200;
            SM_Settings.nObjective=3;
            nPop=12;
            nVar=10;
            VarMin(1:2)=0;
            VarMax(1:2)=1;
            VarMin(3:nVar)=-1;
            VarMax(3:nVar)=1;
        case num2cell([7 8])
            SM_Settings.nRep=100;
            SM_Settings.nObjective=2;
            nPop=8;
            nVar=10;
            VarMin(1:nVar)=0;
            VarMax(1:nVar)=1;
        case num2cell([9])
            SM_Settings.nRep=100;
            SM_Settings.nObjective=2;
            nPop=8;
            nVar=30;
            VarMin(1)=0;
            VarMax(1)=1;
            VarMin(2:nVar)=-1;
            VarMax(2:nVar)=1;
    end
    
    VarSize=[1 nVar];   % Decision Variables Matrix Size
    alpha=2;
    %% SEARCH MANAGER Parameters

    evaluations = 450000;   % number of fitness function evalutions                    % Population Size
    MaxIt=ceil(evaluations/nPop);             % Maximum Number of Iterations
    TotalRun=30;
    
	MaxProbInfSelection = 0.2;
    ProbInfSelection = 1.00003;
    ProbInfSelectionStep = 1.00003;
    count_inf_selection=0;
    
    p=logspace(1, 5, MaxIt)./10^5;
    Inf_P=rand(1, MaxIt);
    %sum(count)
    
    Inf_Max_P=0.2;
    Inf_P0 = 1.00003;
    Inf_P_step=1.00003;
            
    
% case 1 % Simulated binary crossover 
% case 2  %SinCosein
% case 3      %DE from ADE-MOAIS 
% case 4 % Uniform mutation
% case 5 %WOA
% case 6  %FA
% case 7  %Gaussian Mutation
% case 8 %Polynomial Mutation
% case 9 %Sin Cosin 
% case 10  % Extended line crossover  or BLX-0.25 
% case 11 % Modified GWO 
% case 12  %TLBO Teaching
% case 13  %TLBO Learning 
% case 14  %Bat


    %Style1
    %Style_pool=[3, 1, 14, 7]; %not bad
    %score = [37    64    10   309]
    %Problem= 1 : Run= 1 : Iteraion 10000: Number of Repository Members = 100: HV = 0.35562: IGD+ = 0.0027655: eps = 0.14573
    
    %style2
    %Style_pool=[1, 3, 4, 7, 8, 14]; %not bad
    %score = [45    41    16   411    52    17]
    %Problem= 1 : Run= 1 : Iteraion 10000: Number of Repository Members = 100: HV = 0.31738: IGD+ = 0.0057403: eps = 0.19183
    
    %style3
    %Style_pool=[1, 3, 4, 7, 14]; %acanmadi
    %score = [89    53    18   269    20]
    %Problem= 1 : Run= 1 : Iteraion 10000: Number of Repository Members = 100: HV = 0.31657: IGD+ = 0.0050309: eps = 0.16936
    
    %style4
    %Style_pool=[1, 3, 5, 7, 9, 11, 13]; 
    %scores=[23    26   105   875    60     1    16]
    %
    %style5
    %Style_pool=[5, 7, 9];
    %very bad
    
    
    %style6
    %Style_pool=[1, 5, 7];
    %very bad
    
    %style7
    Style_pool=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
    
    %Problem= 1 : Run= 1 : Iteraion 10000: Number of Repository Members = 100: HV = 0.47379: IGD+ = 1.2424e-05: eps = 0.01204
    
    nStyle=numel(Style_pool);
    %% Initialization
    ProblemSettings.CostFunction=CostFunction;
    ProblemSettings.nVar=nVar;
    ProblemSettings.VarSize=VarSize;
    ProblemSettings.VarMin=VarMin;
    ProblemSettings.VarMax=VarMax;
    ProblemSettings.MaxIt=MaxIt;

    SM_Settings.MaxIt=MaxIt;
    SM_Settings.nPop=nPop;    
    SM_Settings.nHistory=10;
    SM_Settings.nStyle=nStyle;
    SM_Settings.Style_pool=Style_pool;
    SM_Settings.alpha=alpha;
    SM_Settings.L=0.2;

    IGDs=zeros(MaxIt, TotalRun);
    HVs=zeros(MaxIt, TotalRun);
    Eps=zeros(MaxIt, TotalRun);
    IGDPs=zeros(MaxIt, TotalRun);

    % Initialize Organization
    for run=1:TotalRun

        it=0;
        Structure=Create_Initial_Stucture(); 

        %% Determine Domination & Create Initial Repository
        Rep = [];
        Rep2 = [];
        Structure=DetermineDomination(Structure, 0);
        Rep = MakeRepository(Structure, Rep);
        Rep2 = Rep;

        %% Search Manager Main Loop
        for it=1:MaxIt    
            SM_Settings.L=(((MaxIt-it)/MaxIt)*0.5);
            
            % Movement Operation           
            if rand>exp(-(it-MaxIt)^2/(30*MaxIt))
                Structure=Movement(Structure, Rep, Rep2, it);
            else
                Structure=Movement2(Structure, Rep, Rep2, it);
                count_inf_selection = count_inf_selection+1;
            end

            % Dominations ...
            Structure=DetermineDomination(Structure, 0);

            Rep=MakeRepository(Structure, Rep);        
     
            rep_cos=[Rep.Cost];
            
            IGDs(it,run)=IGD([Rep.Cost]',PF);
            IGDps(it,run)=IGDP([Rep.Cost]',PF);
            HVs(it,run)=HV([Rep.Cost]',PF);
            Eps(it,run)=Epsilon([Rep.Cost]',PF);
            disp(['Problem= ' num2str(Problem) ' : Run= ' num2str(run) ' : Iteraion ' num2str(it) ': Number of Repository Members = ' num2str(numel(Rep)) ': Count of Inf Selections = ' num2str(count_inf_selection) ': HV = ' num2str(HVs(it,run)) ': IGD+ = ' num2str(IGDps(it,run)) ': eps = ' num2str(Eps(it,run))]);

            %Plot Costs
            %if rem(it, 200)==0
%                 figure(1);
%                 PlotCosts2([Rep.Cost]);
%                 pause(0.0001); 
            %end
        end
    
        disp(['==============================================================' ]);
        disp(['Statistics:' ]);
        disp(['Hypervolume: \t Median:' median(HVs(end,:)) '\t IRQ:' iqr(HVs(end,:)) ]);
        disp(['IGD: \t Median:' median(IGDs(end,:)) '\t IRQ:' iqr(IGDs(end,:)) ]);
        AllReps(run).Cost=[Rep.Cost]';
        save(['D://microMOSM_' problemName '.mat'],'HVs','IGDps','Eps','IGDs', 'Rep', 'AllReps');

    end
   
end
    

