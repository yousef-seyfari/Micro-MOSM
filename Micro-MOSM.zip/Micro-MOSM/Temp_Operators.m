case 1 %Sin Cosin
                
                %abest
                a = 2;
                    
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                if all(cds==inf)
                    cds = ones(size(cds));
                else
                    cds(cds==inf) = 2*max(cds(cds~=inf));
                end
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2; 
                P3=1-P3;
                P=0.3*P3+0.7*P1;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);% 

                mm=(Rep(Selected_Sol).Decision-Structure(i).Decision);

                r1=a-it*((a)/MaxIt); 

                r2=(2*pi)*randn();
                r3=2*randn;
                r4=randn();

                if r4<=0.5
                    newSol= Structure(i).Decision+r1*(sin(r2)*abs(r3*mm - ...
                        Structure(i).Decision));
                else                   
                    newSol= Structure(i).Decision+r1*(cos(r2)*(r3*mm - ...
                        Structure(i).Decision));
                end
             
                newSol = max(newSol, VarMin);
                newSol = min(newSol, VarMax);

                Structure(i).Decision=newSol;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=CostFunction(newSol);

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

case 20 % CMX Crossover
                
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2;
                P1=1-P1;
                P=0.4*P3+0.6*P1;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);% 
                rr=randi(numel(Structure));
                rr2=randi(numel(Rep));
                m=1/3*(Structure(rr).Decision+Rep(Selected_Sol(1)).Decision+Rep(rr2).Decision);
                %m=1/2*(Structure(rr).Decision-Rep(Selected_Sol).Decision);
                
                %xv=3*m-Structure(i).Decision;
                xv=2*m-Structure(i).Decision;
                alpha=rand(VarSize);
                y1.Decision=zeros(1,nVar);
                y1.Decision=alpha.*(xv-Structure(i).Decision)+...
                         Structure(i).Decision;                 

                y1.Decision = max(y1.Decision, VarMin);
                y1.Decision = min(y1.Decision, VarMax);
                 
                y1.Cost=CostFunction(y1.Decision);                    
                          
                Structure(i).Decision=y1.Decision;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=y1.Cost;

                 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 2888 % ??? Crossover
                
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2;
                P1=1-P1;
                P=0.6*P3+0.4*P1;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);%   

                Parent1=Structure(i);
                Parent2=Rep(Selected_Sol(1));                               
                
                alpha=rand(VarSize);
                y1=Parent1;y2=Parent1;
                y1.Decision=Parent1.Decision+alpha.*(Parent2.Decision-Parent1.Decision);
                y2.Decision=Parent2.Decision+alpha.*(Parent2.Decision-Parent1.Decision);

                y1.Decision = max(y1.Decision, VarMin);
                y1.Decision = min(y1.Decision, VarMax);
                y2.Decision = max(y2.Decision, VarMin);
                y2.Decision = min(y2.Decision, VarMax);
                
%                 [proC,disC,proM,disM] = deal(1,20,1,5);
%                 Site  = rand(2*1,nVar) < proM/nVar;
%                 mu    = rand(2*1,nVar);
%                 temp  = Site & mu<=0.5;
%                 y=[y1.Decision
%                     y2.Decision];
%                 y(temp) = y(temp)+(VarMax-VarMin).*((2.*mu(temp)+(1-2.*mu(temp)).*...
%                                   (1-(y(temp)-VarMin)./(VarMax-VarMin)).^(disM+1)).^(1/(disM+1))-1);
%                 temp = Site & mu>0.5; 
%                 y(temp) = y(temp)+(VarMax-VarMin).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
%                                   (1-(VarMax-y(temp))./(VarMax-VarMin)).^(disM+1)).^(1/(disM+1)));
%                 y   = min(max(y,VarMin),VarMax);    
%                 y1.Decison=y(1,:);
%                 y2.Decison=y(2,:);
                y1.Cost=CostFunction(y1.Decision);                    
                y2.Cost=CostFunction(y2.Decision);  

                if rand<=0.5
                    Structure(i).Decision=y1.Decision;
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Cost=y1.Cost;
                else
                    Structure(i).Decision=y2.Decision;
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Cost=y2.Cost;
                end
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
            case 12  %Arithmetic crossover
                alpha=rand(VarSize);
                
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                if all(cds==inf)
                    cds = ones(size(cds));
                else
                    cds(cds==inf) = 2*max(cds(cds~=inf));
                end
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2;
                P1=1-P1;
                P=1*P3+0.0*P1;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);%                 
                
                y1.Decision=(1-alpha).*Structure(i).Decision+(alpha).*(Rep(Selected_Sol).Decision);
                y2.Decision=alpha.*Rep(Selected_Sol).Decision+(1-alpha).*Structure(i).Decision;

                y1.Decision=max(y1.Decision,VarMin);
                y1.Decision=min(y1.Decision,VarMax);

                y2.Decision=max(y2.Decision,VarMin);
                y2.Decision=min(y2.Decision,VarMax);
                
                y1.Cost=CostFunction(y1.Decision); 
                y2.Cost=CostFunction(y2.Decision); 
                
                if Dominates(y1.Cost, y2.Cost)
%                     Costs=[Structure.Cost];
%                     res=find(all(Costs>=y1.Cost) & any(Costs>y1.Cost));           
%                     if ~isempty(res)
%                         kk=randi(numel(res));
%                         Structure(res(kk)).Decision=y1.Decision;
%                         Structure(res(kk)).PrevCost=Structure(res(kk)).Cost;
%                         Structure(res(kk)).Cost=y1.Cost;
%                     end                    
                    Structure(i).Decision=y1.Decision;
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Cost=y1.Cost;
                else
%                     Costs=[Structure.Cost];
%                     res=find(all(Costs>=y2.Cost) & any(Costs>y2.Cost));           
%                     if ~isempty(res)
%                         kk=randi(numel(res));
%                         Structure(res(kk)).Decision=y2.Decision;
%                         Structure(res(kk)).PrevCost=Structure(res(kk)).Cost;
%                         Structure(res(kk)).Cost=y2.Cost;
%                     end
                    Structure(i).Decision=y2.Decision;
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Cost=y2.Cost;
                end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
            case 777  %Geometric crossover
                
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2;
                P1=1-P1;
                P=0.55*P1+0.45*P3;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);%                  
                
                y1.Decision=(0.5).*Structure(i).Decision+(0.5).*(Rep(Selected_Sol).Decision);
                
                y1.Decision=max(y1.Decision,VarMin);
                y1.Decision=min(y1.Decision,VarMax);
                
                y1.Cost=CostFunction(y1.Decision); 
                
                
                Structure(i).Decision=y1.Decision;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=y1.Cost;

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 1010 %PSO                
                w=1-it/MaxIt;
                
                dists=[Rep.Dist];
                cds=[Rep.CD];
                s_costs=sum([Rep.Cost],1);
                P1=exp(-cds/sum(cds));
                P2=exp(-dists/sum(cds));
                P3=exp(-s_costs/sum(s_costs));
                P1=1-P1;
                P2=1-P2;
                s_costs=sum([Rep.Cost],1);

                P=0.6*P1+0.4*P2;
                P=P/sum(P);
                Selected_Sol=randi(numel(Rep));%RouletteWheelSelection(P,1);%
                
                mm=Rep(Selected_Sol).Decision;
                
                Structure(i).Velocity = w*Structure(i).Velocity ...
                +1.5*rand(VarSize).*(Structure(i).BestP-Structure(i).Decision) ...
                +1.5*rand(VarSize).*(mm-Structure(i).Decision);

                % Apply Velocity Limits
                Structure(i).Velocity = max(Structure(i).Velocity,VarMin);
                Structure(i).Velocity = min(Structure(i).Velocity,VarMax);

                % Velocity Mirror Effect
                IsOutside=( Structure(i).Decision<VarMin |  Structure(i).Decision>VarMax);
                Structure(i).Velocity(IsOutside)=-Structure(i).Velocity(IsOutside);
                % Update Position
                Structure(i).Decision = Structure(i).Decision + Structure(i).Velocity;
                % Apply Position Limits
                Structure(i).Decision = max(Structure(i).Decision,VarMin);
                Structure(i).Decision = min(Structure(i).Decision,VarMax);
                
                % Evaluation
                t2 = CostFunction(Structure(i).Decision);

                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=t2;
                    
                if  Dominates(Structure(i).Cost, Structure(i).BestC) 
                    Structure(i).BestP=Structure(i).Decision;
                    Structure(i).BestC=Structure(i).Cost;
                end
                    
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 885  %DE                                                                        
                r=randsample(numel(Structure),1,'false');   
                dists=[Rep.Dist];
                cds=[Rep.CD];
                s_cds=sum(cds,1);
                s_costs=sum([Rep.Cost],1);
                
                P1=exp(-s_cds/sum(s_cds));
                P2=exp(-dists/sum(dists));
                P3=exp(-s_costs/sum(s_costs));
                P1=1-P1;
                P2=1-P2;
                P=0.5*P1+0.5*P3;
                P=P/sum(P);                
                Selected_Sol=RouletteWheelSelection(P,1);%
                % Differental evolution
                [CR,F,proM,disM] = deal(1,0.5,1,20);
                Site = rand(1,nVar) < CR;
                Offspring       = Structure(i).Decision;
                Offspring(Site) = Offspring(Site) + F*(Rep(Selected_Sol).Decision(Site)-Structure(r).Decision(Site));

                % Polynomial mutation
                Site  = rand(1,nVar) < proM/nVar;
                mu    = rand(1,nVar);
                temp  = Site & mu<=0.5;
                Offspring       = min(max(Offspring,VarMin),VarMax);
                Offspring(temp) = Offspring(temp)+(VarMax-VarMin).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                                  (1-(Offspring(temp)-VarMin)./(VarMax-VarMin)).^(disM+1)).^(1/(disM+1))-1);
                temp = Site & mu>0.5; 
                Offspring(temp) = Offspring(temp)+(VarMax-VarMin).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                                  (1-(VarMax-Offspring(temp))./(VarMax-VarMin)).^(disM+1)).^(1/(disM+1)));
                
                
%                     U=Structure(i).Group(r(1)).Decision+rand*(...
%                         Structure(i).Group(r(2)).Decision-Structure(i).Group(r(3)).Decision);  
%                 beta=unifrnd(0,1,VarSize);
%                 U=Structure(r(1)).Decision+beta.*(...
%                      Structure(r(2)).Decision-Structure(r(3)).Decision);                    
% 
%                 sol.Decision=zeros(1,nVar);
% 
%                 j0=randi([1 nVar]);
%                 for k=1:nVar
%                     if k==j0 || rand<=0.8
%                         sol.Decision(k)=U(k);
%                     else
%                         sol.Decision(k)=Structure(i).Decision(k);
%                     end
%                 end

                %for k=1:nVar
                    %if rand<=0.1 || k==tt
                        %sol.Decision(1,index1)=U(1,index1);
                    %else
                        %sol.Decision(1,index2)=Structure(i).Decision(index2);
                    %end
                %end 
                Offspring = max(Offspring,VarMin);               
                Offspring = min(Offspring,VarMax);
                Offspring_Cost = CostFunction(Offspring);           
                
%                 Costs=[Structure.Cost];
%                 res=find(all(Costs>=sol.Cost) & any(Costs>sol.Cost));           
%                 if ~isempty(res)
%                     kk=randi(numel(res));
%                     Structure(res(kk)).Decision=sol.Decision;
%                     Structure(res(kk)).PrevCost=Structure(res(kk)).Cost;
%                     Structure(res(kk)).Cost=sol.Cost;   
%                 end  
%                 if Dominates(Offspring_Cost, Structure(i).Cost) 
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Decision=Offspring;
                    Structure(i).Cost=Offspring_Cost;   
%                 else
%                     Structure(i).PrevCost=Structure(i).Cost;
%                 end  
%                                                        
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                
            case 1232 %TLBO
                
                Mean = 0;
                for k=1:numel(Structure)
                    Mean = Mean + Structure(k).Decision;
                end
                Mean = Mean/numel(Structure);
                empty_individual=Structure(i);
                
                dists=[Rep.Dist];
                cds=[Rep.CD];
                s_cds=sum(cds,1);
                s_costs=sum([Rep.Cost],1);
                
                P1=exp(-s_cds/sum(s_cds));
                P2=exp(-dists/sum(dists));
                P3=exp(-s_costs/sum(s_costs));
                P1=1-P1;
                P2=1-P2;
                %P3=1-P3;
                P=0.6*P1+0.4*P2;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);%
                
                mm=Rep(Selected_Sol).Decision;                

                %Teacher Phase                 
                newsol = empty_individual;
                TF = randi([1 2]);
                newsol.Decision = Structure(i).Decision+ rand(VarSize).*(mm - TF*Mean);
                % Clipping
                newsol.Decision = max(newsol.Decision, VarMin);
                newsol.Decision = min(newsol.Decision, VarMax);
                newsol.PrevCost=Structure(i).Cost;
                newsol.Cost = CostFunction(newsol.Decision);
                newsol.Velocity=Structure(i).Velocity;
                newsol.BestP=newsol.Decision;
                newsol.BestC=newsol.Cost;
                if Dominates(newsol.Cost,Structure(i).Cost)
                    Structure(i) = newsol;
                end                                                    
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 9992
                
                Mean = 0;
                for k=1:numel(Structure)
                    Mean = Mean + Structure(i).Decision;
                end
                Mean = Mean/numel(Structure);
                empty_individual=Structure(i);
                       
                %Learning Phase
                A = 1:numel(Structure);
                A(i)=[];
                k = A(randi(numel(Structure)-1));
                Step = Structure(i).Decision - Structure(k).Decision;
                if Dominates(Structure(k).Cost,Structure(i).Cost)
                    Step = -Step;
                elseif Dominates(Structure(i).Cost,Structure(k).Cost)
                    
                else
                    Step = Rep(randi(numel(Rep))).Decision - Structure(i).Decision;
                end
                newsol = empty_individual;
                newsol.Decision = Structure(i).Decision + rand(VarSize).*Step;
                % Clipping
                newsol.Decision = max(newsol.Decision, VarMin);
                newsol.Decision = min(newsol.Decision, VarMax);
                newsol.Cost = CostFunction(newsol.Decision);
                newsol.PrevCost=Structure(i).Cost;
                if Dominates(newsol.Cost,Structure(i).Cost)
                    Structure(i) = newsol;
                else
                    Structure(i).PrevCost=newsol.Cost;
                end  
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            case 486 %ICA Assimilation                    
                
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2;   
                P3=1-P3;
                P=0.95*P1+0.05*P3;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);%    
                temp=[];
                temp.Decision=[];
                temp.Cost=[];
                temp.Decision  = Structure(i).Decision+ ...
                     2*rand(VarSize).*(Rep(Selected_Sol).Decision-Structure(i).Decision); 

                temp.Decision = max(temp.Decision, VarMin);
                temp.Decision = min(temp.Decision, VarMax);

                temp.Cost=CostFunction(temp.Decision);

                Structure(i).Decision=temp.Decision;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=temp.Cost;                    
case 9595 %BAT 
                
                L=1-1/MaxIt;
                Qmin=0;
                Qmax=2;                
                y=[];
                y.Decision=[];
                sigma=0.01*(VarMax-VarMin);

                y.Decision=Structure(i).Decision;

                Q=unifrnd(0,2,VarSize); %?Qmin+(Qmax-Qmin)*rand;

                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2;
                P3=1-P3;
                P=0.35*P3+0.65*P1;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);% 
                
                mm=(Rep(Selected_Sol).Decision-Structure(i).Decision);
                  
                Structure(i).Velocity=Structure(i).Velocity+Q.*mm;
                  
                y.Decision=Structure(i).Decision+Structure(i).Velocity;                  
                                 
                % Pulse rate  r decreasing
                if rand<0%L                  
                    [proC,disC,proM,disM] = deal(1,20,1,5);
                    Site  = rand(1,nVar) < proM/nVar;
                    mu    = rand(1,nVar);
                    temp  = Site & mu<=0.5;
                    Offspring=Structure(i).Decision;
                    Offspring(temp) = Offspring(temp)+(VarMax-VarMin).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                                      (1-(Offspring(temp)-VarMin)./(VarMax-VarMin)).^(disM+1)).^(1/(disM+1))-1);
                    temp = Site & mu>0.5; 
                    Offspring(temp) = Offspring(temp)+(VarMax-VarMin).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                                      (1-(VarMax-Offspring(temp))./(VarMax-VarMin)).^(disM+1)).^(1/(disM+1)));
                    Structure(i).Decision=Offspring;
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Cost=CostFunction(Offspring);
                end

                y.Decision = max(y.Decision, VarMin);
                y.Decision = min(y.Decision, VarMax);                

                y.Cost=CostFunction(y.Decision);
                %if Dominates(y.Cost,Structure(i).Cost) 
                    Structure(i).Decision=y.Decision;
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Cost=y.Cost;
                %end

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            case 35215  %WOA
                
                a=1-it*((1)/MaxIt);
                a2=-1+it*((-1)/MaxIt);  

                r1=rand();%unifrnd(-1,1); % rand();% r1 is a random number in [0,1]
                r2=rand();%unifrnd(-1,1); % rand();% r2 is a random number in [0,1]

                A=2*a*r1-a;  
                C=2*r2;     
                b=1;               
                l=(a2-1)*rand()+1;   

                p = rand();     

                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2; 
                P3=1-P3;
                P=0.6*P1+0.4*P3;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);%
                
                if p<0.5   
                    if abs(A)>=1
                        D_X_rand=abs(C*Rep(Selected_Sol).Decision-Structure(i).Decision); 
                        offspring=Rep(Selected_Sol).Decision-A*D_X_rand;     

                    elseif abs(A)<1
                        D_Leader=abs(C*Rep(Selected_Sol).Decision-Structure(i).Decision); 
                        offspring=Rep(Selected_Sol).Decision-A*D_Leader;     
                    end

                elseif p>=0.5

                    distance2Leader=abs(Rep(Selected_Sol).Decision-Structure(i).Decision);
                    offspring=distance2Leader*exp(b.*l).*cos(l.*2*pi)+Rep(Selected_Sol).Decision;

                end
                offspring = max(offspring,VarMin);
                offspring = min(offspring,VarMax);

                offspring_cost = CostFunction(offspring);
                
                Structure(i).Decision=offspring;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=offspring_cost;

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 108  %MFO
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2; 
                P3=1-P3;
                P=0.50*P2+0.00*P3+0.50*P1;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);%
                
                a=-1-it*((1/MaxIt));                
                Flame_no=round(numel(Structure)-it*((numel(Structure)-1)/MaxIt));
                newsol=Structure(i);

                   if i<=Flame_no
                       distance_to_flame=(Rep(Selected_Sol).Decision-Structure(i).Decision);
                       b=1;
                       t=(a-1)*rand+1;
                       newsol.Decision=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+Rep(Selected_Sol).Decision;                           
                   end
                   if i>Flame_no
                       distance_to_flame=(Rep(Selected_Sol).Decision-Structure(i).Decision);
                       b=1;
                       t=(a-1)*rand+1;
                       newsol.Decision=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+Rep(Selected_Sol).Decision;
                   end

                newsol.Decision = max(newsol.Decision, VarMin);
                newsol.Decision = min(newsol.Decision, VarMax);
                newsol.Cost=CostFunction(newsol.Decision);

                Structure(i).Decision=newsol.Decision;
                Structure(i).PrevCost=Structure(i).Cost;
                Structure(i).Cost=newsol.Cost;

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 120
                sigma=0.01*(VarMax-VarMin);
                T=1-(((it)/MaxIt)^3);
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2; 
                P3=1-P3;
                P=0.50*P2+0.00*P3+0.50*P1;
                P=P/sum(P);
                Selected_Sol=RouletteWheelSelection(P,1);%

                RadSize = ceil(numel(Structure)/3);
                if mod(RadSize, 2) == 1
                    RadSize = RadSize - 1;
                end
                if rand < 0.5
                    CondSize = ceil((numel(Structure) - RadSize)/2);
                    ConvSize = numel(Structure) - RadSize - CondSize;
                else
                    ConvSize = ceil((numel(Structure) - RadSize)/2);
                    CondSize = numel(Structure) - RadSize - ConvSize;
                end
                
                arranged = randperm(numel(Structure));
                CondPop = Structure(arranged(1:CondSize)); % Population for conduction phase
                ConvPop = Structure(arranged(CondSize + 1:CondSize + ConvSize)); % Population for convection phase
                RadPop = Structure(arranged(CondSize + ConvSize + 1:numel(Structure))); % Population for radiati phase
                
                newCondPop=CondPop(1);
                for j=1:numel(CondPop)
                    mulfac = rand(1,nVar);
                    newCondPop(j).Decision=CondPop(j).Decision-mulfac.*CondPop(j).Decision;
                end
                
                newConvPop=ConvPop(1);
                ConFac = rand(1,nVar).*(Rep(Selected_Sol).Decision.*randi([1 2],1,nVar));
                for j=1:ConvSize
                    newConvPop(j).Decision = ConvPop(j).Decision + ConFac;
                end              
                                                
                newRadPop1=RadPop(1);
                for j=1:fix(RadSize/2)+1
                    mulfac = rand(1,nVar);                    
                    newRadPop1(j).Decision = RadPop(j).Decision - mulfac.*(RadPop(j).Decision - RadPop(randi(RadSize)).Decision );
                end
                
                newRadPop2=RadPop(1);
                ind=0;
                for j=fix(RadSize/2)+2:RadSize
                    ind=ind+1;
                    mulfac = rand(1,nVar);                    
                    newRadPop2(ind).Decision = RadPop(j).Decision - mulfac.*(RadPop(j).Decision - RadPop(randi(RadSize)).Decision );
                end
                newPopulation=[newCondPop newConvPop newRadPop1 newRadPop2];
                for j=1:numel(newPopulation)
                    newPopulation(j).Decision = max(newPopulation(j).Decision, VarMin);
                    newPopulation(j).Decision = min(newPopulation(j).Decision, VarMax);
                    newPopulation(j).Cost=CostFunction(newPopulation(j).Decision);
                    if j<=numel(Structure)
                        if Dominates(newPopulation(j).Cost,Structure(j).Cost)
                            Structure(j).Decision=newPopulation.Decision;
                            Structure(j).PrevCost=Structure(i).Cost;
                            Structure(j).Cost=newPopulation.Cost;
                        elseif rand<T
%                              y.Decision=zeros(1,nVar);
%                              mu=0.02;
%                              nMu=ceil(mu*nVar);
%                              kk=randsample(nVar,nMu);
%                              y.Decision(kk)=Structure(i).Decision(kk)+...
%                                  sigma.*randn(size(kk'));
%                              y.Cost = CostFunction(y.Decision);
%                              Structure(i).Decision=y.Decision;
%                              Structure(i).PrevCost=Structure(i).Cost;
%                              Structure(i).Cost=y.Cost;
                        end
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            case 16
                % Select Source Site
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2; 
                P3=1-P3;
                P=0.0*P2+0.75*P3+0.25*P1;
                P=P/sum(P);
                rol=RouletteWheelSelection(P,1);%randi(numel(Rep));%

                A=1:numel(Structure);
                A(i)=[];
                sel=A(randi(numel(Structure)-1));
                % Define Acceleration Coeff.
                phi=unifrnd(0,2,VarSize);  
                kk=randperm(nVar);
                dis_point=randi(nVar-1);
                archive_dim=kk(1:dis_point);
                pop_dim=kk(dis_point+1:end);

                mm_arch=(Rep(rol).Decision);%-Structure(i).Decision);
                mm_pop=(Structure(sel).Decision-Structure(i).Decision);
                  
                % New Bee Position
                newPosition=zeros(1,nVar);
                newPosition=Structure(i).Decision+(mm_arch-unifrnd(0,2,VarSize).*Structure(i).Decision);
                %newPosition(archive_dim)=Structure(i).Decision(archive_dim)+phi(archive_dim).*(mm_arch(archive_dim)-Structure(i).Decision(archive_dim));
                %newPosition(pop_dim)=Structure(i).Decision(pop_dim)+phi(pop_dim).*(mm_pop(pop_dim)-Structure(i).Decision(pop_dim));
                
                newPosition = max(newPosition, VarMin);
                newPosition = min(newPosition, VarMax);
                % Evaluation
                newCost=CostFunction(newPosition);
                % Comparision
                if Dominates(newCost,Structure(i).Cost)
                    Structure(i).Decision=newPosition;
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Cost=newCost;
                    Structure(i).C=0; 
                elseif ~Dominates(Structure(i).Cost, newCost) && ~Dominates(Structure(i).Cost, newCost)
                    if rand<=0.5
                        Structure(i).Decision=newPosition;
                        Structure(i).PrevCost=Structure(i).Cost;
                        Structure(i).Cost=newCost; 
                    else
                        Structure(i).C=Structure(i).C+1;
                    end
                else
                    Structure(i).C=Structure(i).C+1;
                end
                                
                sigma=0.05*(VarMax-VarMin);
                if Structure(i).C>=5
                    Structure(i).Decision=Structure(i).Decision+sigma*randn(VarSize);
                    Structure(i).Decision = max(Structure(i).Decision, VarMin);
                    Structure(i).Decision = min(Structure(i).Decision, VarMax);
                    %Structure(i).Decision=unifrnd(VarMin,VarMax,VarSize);
                    Structure(i).PrevCost=Structure(i).Cost;
                    Structure(i).Cost=CostFunction(Structure(i).Decision);
                    Structure(i).C=0;                
                end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
            case 150
                
                a=1;
                F=zeros(3,numel(Structure));
                MeanCost = zeros(2,1);                
                for kk=1:numel(Structure)
                    MeanCost(1,1)=MeanCost(1,1)+Structure(kk).Cost(1);
                    MeanCost(2,1)=MeanCost(2,1)+Structure(kk).Cost(2);
                    MeanCost(3,1)=MeanCost(2,1)+Structure(kk).Cost(3);
                end
                MeanCost=MeanCost./numel(Structure);
                for kk=1:numel(Structure)
                    F(:,kk) = exp(-Structure(kk).Cost./MeanCost); % Convert Cost to Fitness
                    P(kk)=(F(1,kk)+F(2,kk))/2;
                end
               
                % Select Source Site
                dists=[Rep.Dist];
                costs=[Rep.Cost];
                cds=[Rep.CD];
                s_costs=sum(costs,1);
                s_cds=sum(cds,1);
                P3=exp(-s_cds/sum(s_cds));
                P1=exp(-s_costs/sum(s_costs));
                P2=exp(-dists/sum(dists));
                P2=1-P2; 
                P3=1-P3;
                P=0.50*P2+0.00*P3+0.50*P1;
                P=P/sum(P);
                rol=RouletteWheelSelection(P,1);%

                % Choose k randomly, not equal to i
                A=1:numel(Structure);
                A(i)=[];
                sel=A(randi(numel(Structure)-1));

                % Define Acceleration Coeff.
                phi=a*unifrnd(0,+1,VarSize);
                
                % New Bee Position
                newPosition=Structure(rol).Decision+phi.*(Structure(rol).Decision-Structure(sel).Decision);
                
                newPosition = max(newPosition, VarMin);
                newPosition = min(newPosition, VarMax);
                % Evaluation
                newCost=CostFunction(newPosition);

                % Comparision
                if Dominates(newCost,Structure(rol).Cost)
                    Structure(rol).Decision=newPosition;
                    Structure(rol).PrevCost=Structure(rol).Cost;
                    Structure(rol).Cost=newCost;
                else
                    Structure(rol).C=Structure(rol).C+1;
                end
                
%                 sigma=0.005*(VarMax-VarMin);
%                 if Structure(rol).C>=1
%                     Structure(rol).Decision=Structure(rol).Decision+sigma*randn(VarSize);
%                     Structure(i).Decision = max(Structure(i).Decision, VarMin);
%                     Structure(i).Decision = min(Structure(i).Decision, VarMax);
%                     Structure(rol).PrevCost=Structure(rol).Cost;
%                     Structure(rol).Cost=CostFunction(Structure(rol).Decision);
%                     Structure(rol).C=0;
%                 end