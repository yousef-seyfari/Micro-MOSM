
function indices=TournmentSelection(P, n)

    len=numel(P); 
    if len<=6
        selected=1:len;
    else
        temp=randperm(len);
        selected=temp(1:6);
    end
    indices=zeros(1,n);
    for j=1:n
        [~,best]=max(P(selected));                     
        indices(j) =best;
        P(best)=0; 
    end
        
end