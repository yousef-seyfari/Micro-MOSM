%% This Function Updates Style Vector For A GROUP
function Structure=Update_Style(Structure, Applied_Style_ID)   
        
    global SM_Settings;
    nStyle=SM_Settings.nStyle;    
    nHistory=SM_Settings.nHistory;
    nObjective=SM_Settings.nObjective;
    
    Others=1:nStyle;
    Others(Applied_Style_ID)=[];
    increase_factor=0.1;
    decrease_factor=0.12;

    if(nStyle<=1)
        Structure.Style(Applied_Style_ID)=Structure.Style(Applied_Style_ID)+0.0001;
        return;
    end 
    
    %%% RATING MECHANISM For MOVEMENT STYLE 
    [~,sz]=size(Structure.History);
     if sz<nHistory
        if isempty(Structure.History)
            Structure.History=Structure.Cost;
            Structure.Style(Applied_Style_ID)=Structure.Style(Applied_Style_ID)+1;
        else
            Structure.History(1:nObjective,end+1) = Structure.Cost;
            Structure.Style(Applied_Style_ID)=Structure.Style(Applied_Style_ID)+1;  
        end
     else

        Structure.History(:,end+1) = Structure.Cost;
        Structure.History(:,1) = [];
        m=sum(Structure.History,2);
        m=m/nHistory;

        if Dominates(Structure.Cost, m)
            Structure.Style(Applied_Style_ID)=Structure.Style(Applied_Style_ID)++1;            
        else
            if Structure.Style(Applied_Style_ID)>1
                Structure.Style(Applied_Style_ID)=Structure.Style(Applied_Style_ID)-1;
            else
               Structure.Style=Structure.Style+1;
               Structure.Style(Applied_Style_ID)=1;
            end
            %Structure.Style(Others)=Structure.Style(Others)+1;
        end
     end
end