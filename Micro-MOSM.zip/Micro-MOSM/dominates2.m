function d = dominates2(fA, fB)

	d = false;
	for i = 1:length(fA)
		if (fA(i) > fB(i))
			d = false;
			return
		elseif (fA(i) < fB(i))
			d = true;
		end
    end
    
end
