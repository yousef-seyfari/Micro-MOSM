function sol=getaSolFromRep2(Rep, Rep2)
%relativly good smooth from both ends
Rep3=Rep;
r = rand;
p1=0.2;
p2=0.02;
p=p1;
if rand<0.2  %original rand<0.5  
    p=p2;
end


selected_solutions_idx = find([Rep(:).CD]==-Inf);
selected_solutions = Rep(selected_solutions_idx);

selected_idx=randi(size(selected_solutions, 2));
sol=selected_solutions(selected_idx);