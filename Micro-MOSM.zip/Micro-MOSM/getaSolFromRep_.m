function  sol=getaSolFromRep(Rep, Rep2)

Rep3=Rep;
r = rand;
p1=0.4;
p2=0.01;
p=p1;
if r<0.9
    p=p2;
end

if r<0.25
    %1
    crowding_distances = [Rep3.CD];
    % Sort Population
    [crowding_distances, SortOrder]=sort(crowding_distances);
    Rep3=Rep3(SortOrder);
    
    r2=randi(max(1, round(numel(Rep3)*p)));
    sol = Rep3(r2);
    
elseif r<0.40
    %1
    crowding_distances = [Rep3.CD];
    % Sort Population
    [crowding_distances, SortOrder]=sort(crowding_distances);
    Rep3=Rep3(SortOrder);
    
    r2=randi(max(1, round(numel(Rep3)*p)));
    sol = Rep3(end-r2);
    
elseif r<1
    %2
    idx=randi(numel(Rep3));
    sol = Rep3(idx);
    
% else
%     %3
%     if(numel(Rep2)==0)
%         Rep2 = Rep;
%     end
%     
%     idx=randi(numel(Rep2));
%     sol = Rep2(idx);
%     Rep2(idx)=[];
end
