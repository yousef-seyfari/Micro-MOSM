function sol=getaSolFromRep(sol, Rep, Rep2)

global FLC

Rep3=Rep;
r = rand;
p1=0.2;
p2=0.02;
p=p1;
if rand<0.56
    p=p2;
end


p23=rand;
p22=(1-p23)*0.2;
p21=1-p23-p22;

solution_state_improving = 0;
if Dominates(sol.Cost, sol.PrevCost)
    solution_state_improving = -1;
elseif Dominates(sol.PrevCost, sol.Cost)
    solution_state_improving = 1;
end



%solution_state=(sol.Cost - sol.PrevCost)/2;
%r=evalfis(solution_state_improving, FLC);%old matlab
r=evalfis(FLC, solution_state_improving);%Matlab 2021a
%pause(0.05); 


if r<0.2
    %1
    crowding_distances = [Rep3.CD];
    % Sort Population
    [crowding_distances, SortOrder]=sort(crowding_distances);
    Rep3=Rep3(SortOrder);
    
    r2=randi(max(1, round(numel(Rep3)*p)));
    sol = Rep3(r2);
    
elseif r<0.7
    %1
    crowding_distances = [Rep3.CD];
    % Sort Population
    [crowding_distances, SortOrder]=sort(crowding_distances);
    Rep3=Rep3(SortOrder);
    
    r2=randi(max(1, round(numel(Rep3)*p)));
    sol = Rep3(end-r2);
    
elseif r<1
    %2
    idx=randi(numel(Rep3));
    sol = Rep3(idx);
    
% else
%     %3
%     if(numel(Rep2)==0)
%         Rep2 = Rep;
%     end
%     
%     idx=randi(numel(Rep2));
%     sol = Rep2(idx);
%     Rep2(idx)=[];
end
