function  sol=getaSolFromRep(Rep, Rep2)
%good2 temiz cixir

r = rand;

if r<0.15
    %1
    crowding_distances = [Rep.CD];
    [~, idx] = min(crowding_distances(2:end-1));
    sol = Rep(idx+1);
    
elseif r<0.30
    crowding_distances = [Rep.CD];
    [~, idx] = min(crowding_distances(2:end-1));
    r2=randi(max(1, round(numel(Rep)*0.1)));
    sol = Rep(idx+r2);
    
elseif r<0.45
    crowding_distances = [Rep.CD];
    [~, idx] = max(crowding_distances);
    sol = Rep(idx);
    
elseif r<1
    %2
    idx=randi(numel(Rep));
    sol = Rep(idx);
    
else
    %3
    if(numel(Rep2)==0)
        Rep2 = Rep;
    end
    
    idx=randi(numel(Rep2));
    sol = Rep2(idx);
    Rep2(idx)=[];
end
